package ejer1;

public class Pieza {
     static int numPieza;
     int nPieza;

    public Pieza() {
        numPieza+=1;
        this.nPieza = numPieza;
    }
}
